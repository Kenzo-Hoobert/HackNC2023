# Imports
import pygame
import pygame_gui
import sys
import random
from pygame.locals import (
    K_ESCAPE,
    KEYDOWN,
    QUIT,
)

# Set buttons objects
objects = []

pygame.mixer.init()

# ---------- Variables ------------------------------
# Initiate pygame
pygame.init()
fps = 60

# initiate pygame_gui manager and clock
manager = pygame_gui.UIManager((1280, 720))
clock = pygame.time.Clock()

# Background music
pygame.mixer.music.load("John Deere.mp3")
pygame.mixer.music.play(loops=-1)

# Screen size - Making the Background
screen = pygame.display.set_mode([1280, 720])
pygame.display.set_caption("John Deere's Great Pumpkin Harvest")
dt = 0


buttonFont = pygame.font.SysFont('Arial', 25)

# textbox -------------------------------------------------
text = buttonFont.render("Welcome to John Deere's Great Pumpkin Harvest!", True, (0, 0, 0))
textRect = text.get_rect()
textRect.center = (625, 585)

# shop/stats text
s_text= buttonFont.render("Shop", True, (0, 0, 0))
s_textRect = text.get_rect()
s_textRect.center = (790, 95)

a_text= buttonFont.render("Actions", True, (0, 0, 0))
a_textRect = text.get_rect()
a_textRect.center = (1180, 95)


# Initialize images
transparent = (0, 0, 0, 0)
i_logo = pygame.image.load("Images/logo.jpg")
i_logo = pygame.transform.scale(i_logo, (190, 190))

i_potato = pygame.image.load("Images/potato.png")
i_potato = pygame.transform.scale(i_potato, (40, 40))

i_parsley = pygame.image.load("Images/parsley.png")
i_parsley = pygame.transform.scale(i_parsley, (40, 40))

i_peas = pygame.image.load("Images/peas.png")
i_peas = pygame.transform.scale(i_peas, (40, 40))

i_corn = pygame.image.load("Images/corn.png")
i_corn = pygame.transform.scale(i_corn, (40, 40))

i_tomato = pygame.image.load("Images/tomato.png")
i_tomato = pygame.transform.scale(i_tomato, (40, 40))

i_cabbage = pygame.image.load("Images/cabbage.png")
i_cabbage = pygame.transform.scale(i_cabbage, (40, 40))

i_carrot = pygame.image.load("Images/carrot.png")
i_carrot = pygame.transform.scale(i_carrot, (40, 40))

i_pumpkin = pygame.image.load("Images/pumpkin.png")
i_pumpkin = pygame.transform.scale(i_pumpkin, (40, 40))

i_sun = pygame.image.load("Images/sun.png")
i_sun = pygame.transform.scale(i_sun, (70, 70))

i_rain = pygame.image.load("Images/rain.png")
i_rain = pygame.transform.scale(i_rain, (70, 70))


## ----------- Variables -----------------------------------------------------------------------
day = 1
weather = random.choices(["Sunny", "Rainy"], weights = (80, 20))
coins = 200
isShopOpen = False

## --- Plants ---------
potato =  {
    "Water": (3, 8), 
    "Water Value": 5,
    "Value": 10,  # multiple of 10
    }

parsley = {
    "Water": (3, 6), 
    "Water Value": 5,
    "Value": 40,
    }

peas =  {
    "Water": (2, 5), 
    "Water Value": 5,
    "Value": 20,
    }

corn =  {
    "Water": (2, 7), 
    "Water Value": 5,
    "Value": 30,
    }

tomato = {
    "Water": (6, 9), 
    "Water Value": 5,
    "Value": 80,
    }

cabbage = {
    "Water": (4, 6), 
    "Water Value": 5,
    "Value": 200,
    }

carrot = {
    "Water": (4, 8), 
    "Water Value": 5,
    "Value": 50,
    }


pumpkin = {
    "Water": (9, 10), 
    "Water Value": 5,
    "Value": 1000,
    }


# --- What is being planted? ---------
crop_list = {
    '0': {}, 
    '1': {},
    '2': {},
    '3': {}, 
    '4': {},
    '5': {},
    '6': {},
    '7': {},
    '8': {},
    '9': {},
    '10': {},
    '11': {},
    '12': {},
    '13': {},
    '14': {},
    '15': {},
    '16': {},
    '17': {},
    '18': {},
    '19': {},
    '20': {},
    '21': {},
    '22': {},
    '23': {},
    '24': {}
    }

currentIndex = 0

def fun():
    pass

## --- Button class + Buttons ----------
#Button class
class Button():
    def __init__():
        pass
    
    def __init__(self, x, y, width, height, buttonText='Button', onclickFunction = fun(), onePress = False, isLand = False, index=-1, crop='', isGrowing=False):
        self.itself = self
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.buttonText = buttonText
        self.onclickFunction = onclickFunction
        self.onePress = onePress
        self.alreadyPressed = False
        self.isLand = isLand
        self.index = index
        self.crop = crop
        self.isGrowing = isGrowing

        self.fillColors = {
            'normal': '#ffffff',
            'hover': '#666666',
            'pressed': '#333333',
            'ripe': '#ffff00',
            'growing': '#4f7942',
            'tilled': '#6e260e',
            'selected' : '#7cfc00',
        }
        
        self.buttonSurface = pygame.Surface((self.width, self.height))
        self.buttonRect = pygame.Rect(self.x, self.y, self.width, self.height)

        self.buttonSurf = buttonFont.render(buttonText, True, (20, 20, 20))
        objects.append(self)
        
    def updateCrop(self, crop=''):
        self.crop = crop
    
    def process(self):
        global currentIndex
        mousePos = pygame.mouse.get_pos()
        if(self.isLand):
            if self.crop == '' and not self.isGrowing:
                self.buttonSurface.fill(self.fillColors['tilled'])
            elif self.isGrowing:
                self.buttonSurface.fill(self.fillColors['growing'])
            else:
                self.buttonSurface.fill(self.fillColors['ripe'])
            if self.buttonRect.collidepoint(mousePos):
                if pygame.mouse.get_pressed(num_buttons=3)[0]:
                    if self.onePress:
                        self.onclickFunction()
                    elif not self.alreadyPressed:
                        self.onclickFunction
                        self.alreadyPressed = True
                        currentIndex = self.index
                else:
                    self.alreadyPressed = False
        else:
            self.buttonSurface.fill(self.fillColors['normal'])
            if self.buttonText == ' ' and self.index == currentIndex:
                self.buttonSurface.fill(self.fillColors['selected'])
                
            if self.buttonRect.collidepoint(mousePos):
                self.buttonSurface.fill(self.fillColors['hover'])
                if pygame.mouse.get_pressed(num_buttons=3)[0]:
                    self.buttonSurface.fill(self.fillColors['pressed'])
                    if self.onePress:
                        self.onclickFunction()
                    elif not self.alreadyPressed:
                        self.onclickFunction
                        self.alreadyPressed = True
                else:
                    self.alreadyPressed = False
        
        self.buttonSurface.blit(self.buttonSurf, [
            self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
            self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
        ])
        screen.blit(self.buttonSurface, self.buttonRect)
        
        
# All the buttons with their functions --------------------------------------------------
# Initialize all the Plots of land
x_list = []
y_list = []
y = 40
for i in range(5):
    x = 40
    for j in range(5):
        pygame.draw.rect(screen, (166, 123, 91), pygame.Rect((x + 10, y + 10, 50, 50)))
        pygame.draw.rect(screen, (92, 64, 51), pygame.Rect((x, y, 70, 70)))
        Button(x, y, 70, 70, ' ', None, False, False, i*5+j, '', False)
        Button(x+10, y+10, 50, 50, ' ', None, False, True, i*5+j, '', False)
        x_list.append(x)
        y_list.append(y)
        x += 82.5
    y += 82.5

def waterPressed():
    print("Water Button Pressed")
    
    # Printing confirmation in-game
    text = buttonFont.render('Watering...', True, (0,0,0), (255, 222, 0))
    textRect = text.get_rect()
    textRect.center = (625, 585)
    screen.blit(text, textRect)
    
    # Watering plants
    for i in crop_list.keys():
        if "Water Value" in crop_list[i].keys():
            crop_list[i]["Water Value"] += 1
            
Button(787.5, 205, 100, 50, 'Water', waterPressed())

def endDayPressed():
    # check if crop is harvestable, then harvests and adds money
    if "potato" in crop_list:
        coins += potato["Value"] * crop_list.count("potato")
        i_potato.fill(transparent)
        crop_list["potato"] = 0

    if "parsley" in crop_list:
        coins += parsley["Value"] * crop_list.count("parsley")
        i_parsley.fill(transparent)
        crop_list["parsley"] = 0

    if "peas" in crop_list:
        coins += peas["Value"] * crop_list.count("peas")
        i_peas.fill(transparent)
        crop_list["peas"] = 0
    
    if "corn" in crop_list:
        coins += corn["Value"] * crop_list.count("corn")
        i_corn.fill(transparent)
        crop_list["corn"] = 0

    if "tomato" in crop_list:
        coins += tomato["Value"] * crop_list.count("tomato")
        i_tomato.fill(transparent)
        crop_list["tomato"] = 0

    if "cabbage" in crop_list:
        coins += cabbage["Value"] * crop_list.count("cabbage")
        i_cabbage.fill(transparent)
        crop_list["cabbage"] = 0

    if "carrot" in crop_list:
        coins += carrot["Value"] * crop_list.count("carrot")
        i_carrot.fill(transparent)
        crop_list["carrot"] = 0
        
    # Progress day and weather 
    day += 1
    weather = random.choices(["Sunny", "Rainy"], weights = (80, 20))
    ## add messages -----------------------------------------------------------------------------------------------------------------------
    if weather == "Rainy":
        pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((260, 480, 750, 210)))
        text = buttonFont.render('It looks dreary outside...', True, (0,0,0), (255, 222, 0))
        textRect = text.get_rect()
        textRect.center = (625, 585)
        for i in crop_list:
            if crop_list[i]:
                crop_list[i]["Water Level"] += 1
    else:
        pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((260, 480, 750, 210)))
        text = buttonFont.render('The sun is out today!', True, (0,0,0), (255, 222, 0))
        textRect = text.get_rect()
        textRect.center = (625, 585)
        for i in crop_list:
            if crop_list[i]:
                crop_list[i]["Water Level"] -= 1   
                
    # Actually make ending messages for these lol -----------------------------------------------------------------
    if "pumpkin" in crop_list:
        pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((260, 480, 750, 210)))
        text = buttonFont.render('You have won the John Deere pumpkin growing contest!', True, (0,0,0), (255, 222, 0))
        textRect = text.get_rect()
        textRect.center = (625, 585)
    
    elif day == 8:
        pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((260, 480, 750, 210)))
        text = buttonFont.render('Better luck next time!', True, (0, 0, 0), (255, 222, 0))
        textRect = text.get_rect()
        textRect.center = (625, 585)

    else:
        pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((260, 480, 750, 210)))
        text = buttonFont.render(f"It is a new day! Day {day}/7", True, (0, 0, 0))
        textRect = text.get_rect()
        textRect.center = (625, 585)#625585
    
Button(787.5, 305, 100, 50, 'End Day', endDayPressed)

def plantPressed(label = ''):
    global isShopOpen
    global currentIndex
    if label == '':
        isShopOpen = True
        print('Plant button pressed')
    elif isShopOpen and label == 'po':
        screen.blit(i_potato, (x_list[currentIndex], y_list[currentIndex]))
        crop_list[str(currentIndex)] = potato
        objects[currentIndex].updateCrop(objects[currentIndex].itself)
        print('Potato planted')
        isShopOpen = False
        
        
        
    text = buttonFont.render("Select a plant!", True, (0, 0, 0))
    textRect = text.get_rect()
    textRect.center = (625, 585)

Button(1087.5, 205, 100, 50, 'Plant', plantPressed())

def removePressed():
    # if potato seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_potato.get_width(), i_potato.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if parsley seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_parsley.get_width(), i_parsley.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if pea pods:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_peas.get_width(), i_peas.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if corn seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_corn.get_width(), i_corn.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if tomato seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_tomato.get_width(), i_tomato.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if cabbage seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_cabbage.get_width(), i_cabbage.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if carrot seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_carrot.get_width(), i_carrot.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
    # if pumpkin seeds:
        clear_rect = pygame.Rect(x_list[currentIndex], y_list[currentIndex], i_pumpkin.get_width(), i_pumpkin.get_height())
        screen.fill(transparent, clear_rect)
        crop_list[str(currentIndex)] = {}
        
        # Print confirmation
        pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((260, 480, 750, 210)))
        text = buttonFont.render("Tilling with a John Deere plow...", True, (0, 0, 0))
        textRect = text.get_rect()
        textRect.center = (625, 585)
Button(1087.5, 305, 100, 50, 'Till', removePressed)

# -------- Game Start ---------------------------------------------------------------------------------------------
# Begin running the game!
running = True
while running:
    time_delta = clock.tick(60)/1000.0
    for event in pygame.event.get():
        # Stops running if user closes window
        if event.type == QUIT:
            running = False
        # Stops running if user clicks escape key
        elif event.type == KEYDOWN:
            if event.type == K_ESCAPE:
                running = False
        manager.process_events(event)
    manager.update(time_delta)    
    
    # --- Update UI -----------
    screen.fill((52, 119, 42))
    
    # Initialize UI elements
    # Objects that make up the UI
    
    # ---- Stats Menu / Plant Select ------------------------
    pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((480, 30, 215, 420)))

    # ----- User Interface / Shop  ----------------------------------------------
    pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((725, 30, 525, 420)))
    
    ## actions
    # UI title and arrow to other menu
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((882.5, 60, 210, 70)))
    
    # action buttons
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((782.5, 200, 110, 60)))
    # pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((932.5, 200, 110, 60)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((1082.5, 200, 110, 60)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((782.5, 300, 110, 60)))
    # pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((932.5, 300, 110, 60)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((1082.5, 300, 110, 60)))


    # title
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 60, 155, 70)))
    
    # seeds
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 160, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 230, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 300, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 370, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((615, 160, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((615, 230, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((615, 300, 50, 50)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((615, 370, 50, 50)))
    
    
    '''''''''''''''
    # stats -----------------
    # water note
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 360, 155, 60)))
    # actual stats
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 165, 155, 30)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 230, 155, 30)))
    pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((510, 295, 155, 30)))
    '''''''''''''''

    # scroll section for shop
    # pygame.draw.rect(screen, (255, 222, 220), pygame.Rect((782.5, 200, 410, 160)))
        
    # ----- Field -------------------------------------------------------
    ## --- Field Background --------------- 
    pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((30, 30, 420, 420)))
    
    # ----- Text Box -----------------------------------------------------
    pygame.draw.rect(screen, (155, 100, 0), pygame.Rect((30, 480, 980, 210)))

    # ----- Info Box ----------------------------------------------
    pygame.draw.rect(screen, (255, 222, 0), pygame.Rect((1040, 480, 210, 210)))
    pygame.draw.rect(screen, (255, 222, 200), pygame.Rect((1050, 490, 190, 190)))
    # weather exists here
    # pygame.draw.rect(screen, (255, 222, 100), pygame.Rect((1080, 567.5, 130, 30))) ## 1145, 582.5
    # pygame.draw.rect(screen, (255, 222, 100), pygame.Rect((1080, 605, 130, 30))) ## 1145, 620
    # pygame.draw.rect(screen, (255, 222, 100), pygame.Rect((1080, 642.5, 130, 30))) ## 1145, 657.5
    #time_text = font
    
    c_text = buttonFont.render(f'Coins: {coins}', True, (0, 0, 0))
    c_textRect = text.get_rect()
    c_textRect.center = (1330, 647)
    
    info_text = buttonFont.render(f"Day {day}", True, (0, 0, 0))
    info_textRect = text.get_rect()
    info_textRect.center = (1330, 607)
    
    
    #Initiate all the buttons as needed  
    for object in objects:
        object.process() 
    
    # 
    # weather
    if weather == "Rainy":
        screen.blit(i_rain, (1110, 500))
    else:
        screen.blit(i_sun, (1110, 500))
        
    # seeds
    screen.blit(i_potato, (515, 165))
    Button(515, 165, 40, 40, ' ', plantPressed('po'))
    screen.blit(i_parsley, (515, 235))
    Button(515, 235, 40, 40, ' ', plantPressed('py'))
    screen.blit(i_peas, (515, 305))
    Button(515, 305, 40, 40, ' ', plantPressed('ps'))
    screen.blit(i_corn, (515, 375))
    Button(515, 375, 40, 40, ' ', plantPressed('cn'))
    screen.blit(i_tomato, (620, 165))
    Button(620, 165, 40, 40, ' ', plantPressed('to'))
    screen.blit(i_cabbage, (620, 235))
    Button(620, 235, 40, 40, ' ', plantPressed('ce'))
    screen.blit(i_carrot, (620, 305))
    Button(620, 305, 40, 40, ' ', plantPressed('ct'))
    screen.blit(i_pumpkin, (620, 375))
    Button(620, 375, 40, 40, ' ', plantPressed('pn'))
    
    # --- Text Box ----------
    screen.blit(i_logo, (40, 490))
    screen.blit(text, textRect)
    
    # --- Seeds Menu and actions  ---------
    screen.blit(s_text, s_textRect)
    screen.blit(a_text, a_textRect)
    
    # --- Info Box ---------
    screen.blit(info_text, info_textRect)
    screen.blit(c_text, c_textRect)

    # flip() the display to put your work on screen
    pygame.display.flip()

    # limits FPS to 60
    # dt is delta time in seconds since last frame, used for framerate-
    # independent physics.
    dt = clock.tick(fps) / 1000

pygame.quit()
#pygame.display.update()